const { Builder } = require("selenium-webdriver");
const HomePage = require("../pages/HomePage");
const ProductPage = require("../pages/ProductPage");

(async function () {
    // Firefox browser ko setup aur open karna
    let driver = await new Builder().forBrowser("firefox").build();

    try {
        // Task 2: Daraz.pk par jana
        console.log("Opening Daraz...");
        await driver.get("https://www.daraz.pk");
        await driver.manage().window().maximize();
        console.log("Daraz Opened");

        // Task 3: "electronics" search karna
        const home = new HomePage(driver);
        await home.searchProduct();
        await driver.sleep(5000);

        const productPage = new ProductPage(driver);
        
        // Task 4: Brand Filter apply karna
        await productPage.applyBrandFilter();

        // Task 5: Price Filter apply karna (500 se 5000)
        await productPage.applyPriceFilter("500", "5000");

        // Task 6: Products count karna aur validate karna
        let count = await productPage.getProductsCount();
        console.log("Total Products Found:", count);

        if (count > 0) {
            console.log("Validation Result: PASS (Products are greater than 0)");
            
            // Task 7 & 8: Pehla product open karna aur Free Shipping check karna
            await productPage.openFirstProductAndCheckShipping();
        } else {
            console.log("Validation Result: FAIL (0 products found)");
        }

    } catch (error) {
        console.log("Error during test execution:", error);
    } finally {
        // Browser ko close karna
        console.log("Closing browser...");
        await driver.sleep(5000);
        await driver.quit();
    }
})();