const { By, Key, until } = require("selenium-webdriver");

class ProductPage {
    constructor(driver) {
        this.driver = driver;
    }

    // Task 4: Brand Filter lagane ka method (FIXED WITH JAVASCRIPT CLICK)
    async applyBrandFilter() {
        console.log("Applying Brand filter...");
        try {
            // Checkbox element ko locate karna
            let brandCheckbox = await this.driver.wait(
                until.elementLocated(By.xpath("//div[contains(@class, 'filter-panel')]//span[contains(@class, 'ant-checkbox') or @data-qa-locator='filter-item']")),
                10000
            );
            
            // JavaScript ke zarye click karna taake "ElementNotInteractable" ka error na aaye
            await this.driver.executeScript("arguments[0].click();", brandCheckbox);
            console.log("Brand filter applied successfully via JS.");
            await this.driver.sleep(4000); // Page refresh hone ka wait
        } catch (error) {
            console.log("Brand filter custom locator trying...");
            try {
                let alternativeBrand = await this.driver.findElements(By.css(".ant-checkbox-input"));
                if(alternativeBrand.length > 0) {
                    await this.driver.executeScript("arguments[0].click();", alternativeBrand[0]);
                    console.log("Alternative Brand filter applied via JS.");
                    await this.driver.sleep(4000);
                } else {
                    console.log("Could not find any brand filter checkbox, skipping.");
                }
            } catch (err) {
                console.log("Skipping Brand filter due to layout issue.");
            }
        }
    }

    // Task 5: Price Filter lagane ka method (500 se 5000)
    async applyPriceFilter(minPrice, maxPrice) {
        console.log(`Applying price filter: ${minPrice} to ${maxPrice}...`);
        let minInput, maxInput;
        try {
            minInput = await this.driver.wait(
                until.elementLocated(By.xpath("//input[@type='number' or @placeholder='Min']")), 
                10000
            );
            let inputs = await this.driver.findElements(By.xpath("//input[@type='number' or @placeholder='Min' or @placeholder='Max']"));
            if(inputs.length >= 2) { 
                minInput = inputs[0]; 
                maxInput = inputs[1]; 
            }
        } catch (e) {
            let inputs = await this.driver.findElements(By.css("input.ant-input-number-input"));
            minInput = inputs[0]; 
            maxInput = inputs[1];
        }

        if (minInput && maxInput) {
            await minInput.sendKeys(minPrice);
            await maxInput.sendKeys(maxPrice);
            let applyBtn = await this.driver.findElement(By.xpath("//button[contains(@class, 'ant-btn') or text()='OK']"));
            
            // Button par bhi safe click apply kar rahe hain
            await this.driver.executeScript("arguments[0].click();", applyBtn);
            console.log("Price filter applied.");
            await this.driver.sleep(5000); 
        } else {
            throw new Error("Could not find Min or Max price input fields.");
        }
    }

    // Task 6: Products count karne ka method
    async getProductsCount() {
        console.log("Counting products...");
        let products = await this.driver.findElements(By.xpath("//div[@data-qa-locator='product-item']"));
        if (products.length === 0) {
            products = await this.driver.findElements(By.css(".Bm3ON, .ant-col-5"));
        }
        return products.length;
    }

    // Task 7 & 8: Pehla product kholna aur Free Shipping check karna
    async openFirstProductAndCheckShipping() {
        console.log("Opening first product...");
        let products = await this.driver.findElements(By.xpath("//div[@data-qa-locator='product-item']"));
        if(products.length === 0) { 
            products = await this.driver.findElements(By.css(".Bm3ON, .ant-col-5")); 
        }
        
        if(products.length > 0) {
            let firstProductLink = await products[0].findElement(By.xpath(".//a"));
            
            // Product kholne ke liye bhi JS click use kar rahe hain taake koi rukawat na aaye
            await this.driver.executeScript("arguments[0].click();", firstProductLink);
            await this.driver.sleep(5000); 

            console.log("Checking Free Shipping...");
            try {
                let pageText = await this.driver.findElement(By.tagName("body")).getText();
                if(pageText.toLowerCase().includes("free shipping")) {
                    console.log("Result: FREE SHIPPING IS AVAILABLE! 🎉");
                } else {
                    console.log("Result: Free Shipping is NOT available for this product.");
                }
            } catch (err) {
                console.log("Could not determine shipping status:", err.message);
            }
        } else {
            console.log("No products available to click.");
        }
    }
}

module.exports = ProductPage;