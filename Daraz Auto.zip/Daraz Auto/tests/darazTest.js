const { Builder } = require("selenium-webdriver");
// Dono pages ko yahan connect/import kar rahe hain
const HomePage = require("../pages/HomePage");
const ProductPage = require("../pages/ProductPage");

(async function () {
    // Firefox browser build karna
    let driver = await new Builder().forBrowser("firefox").build();

    try {
        console.log("Opening Daraz...");
        await driver.get("https://www.daraz.pk");
        
        // Browser ki window ko bara (maximize) karna taake filters sahi se nazar aayein
        await driver.manage().window().maximize();
        console.log("Daraz Opened");

        // 1. HOME PAGE ACTIONS: Electronics Search karna
        const home = new HomePage(driver);
        await home.searchProduct();
        
        // Search result load hone ka wait
        await driver.sleep(5000);

        // 2. PRODUCT PAGE ACTIONS: Filters aur Verification
        const productPage = new ProductPage(driver);
        
        // Price Filter lagayein: 500 se 5000
        await productPage.applyPriceFilter("500", "5000");

        // Products count karein
        let count = await productPage.getProductsCount();
        console.log("Total Products Found:", count);

        // Check karein ke products 0 se zyada hain ya nahi
        if (count > 0) {
            console.log("Validation Result: PASS");
            
            // Pehla product open karke free shipping check karein
            await productPage.openFirstProductAndCheckShipping();
        } else {
            console.log("Validation Result: FAIL (No products found)");
        }

    } catch (error) {
        console.log("Error during test execution:", error);
    } finally {
        // Test khatam hone ke baad 5 seconds wait karke browser band hoga
        console.log("Closing browser...");
        await driver.sleep(5000);
        await driver.quit();
    }
})();