const { By, Key, until } = require("selenium-webdriver");

class ProductPage {
    constructor(driver) {
        this.driver = driver;
    }

    async applyPriceFilter(minPrice, maxPrice) {
        console.log(`Applying price filter: ${minPrice} to ${maxPrice}...`);
        
        // Daraz ke naye layout me input class 'ant-input-number-input' ya 'ant-space-item' ke andar hoti hai
        // Hum alag-alag tariqon se inputs ko dhoondne ki koshish karenge taake script fail na ho
        let minInput, maxInput;

        try {
            // Tariqa 1: Input type="number" ke zarye (Daraz ka current pattern)
            minInput = await this.driver.wait(
                until.elementLocated(By.xpath("//input[@type='number' or @placeholder='Min']")), 
                10000
            );
            // Pehla input min ka hota hai aur doosra max ka
            let inputs = await this.driver.findElements(By.xpath("//input[@type='number' or @placeholder='Min' or @placeholder='Max']"));
            if(inputs.length >= 2) {
                minInput = inputs[0];
                maxInput = inputs[1];
            }
        } catch (e) {
            console.log("Alternative price locator trying...");
            // Tariqa 2: Agar upar wala fail ho toh class base par dhoondna
            let inputs = await this.driver.findElements(By.css("input.ant-input-number-input"));
            minInput = inputs[0];
            maxInput = inputs[1];
        }

        if (minInput && maxInput) {
            // Puraani value clear karke nayi price likhna
            await minInput.sendKeys(minPrice);
            await maxInput.sendKeys(maxPrice);
            console.log("Prices typed into inputs.");

            // Daraz par price filters apply karne ke liye 'go' ya '>' button hota hai jis par 'ant-btn-primary' class hoti hai
            // Ya phir button ke andar direct text ya icon hota hai
            let applyBtn = await this.driver.findElement(By.xpath("//button[contains(@class, 'ant-btn') or text()='OK']"));
            await applyBtn.click();
            
            console.log("Price filter applied.");
            await this.driver.sleep(5000); // Filter apply hone ke baad products reload hone ka wait
        } else {
            throw new Error("Could not find Min or Max price input fields on the page.");
        }
    }

    async getProductsCount() {
        console.log("Counting products...");
        // Daraz par har product card me ek specific test attribute hota hai jaise 'data-qa-locator' ya class 'Bm3ON'
        // Hum dono check kar lete hain taake safe rahein
        let products = await this.driver.findElements(By.xpath("//div[@data-qa-locator='product-item']"));
        
        if (products.length === 0) {
            products = await this.driver.findElements(By.css(".Bm3ON, .ant-col-5, div[data-item='true']"));
        }

        return products.length;
    }

    async openFirstProductAndCheckShipping() {
        console.log("Opening first product...");
        let products = await this.driver.findElements(By.xpath("//div[@data-qa-locator='product-item']"));
        if(products.length === 0) {
            products = await this.driver.findElements(By.css(".Bm3ON, .ant-col-5"));
        }
        
        if(products.length > 0) {
            // Pehle product par click karna
            let firstProductLink = await products[0].findElement(By.xpath(".//a"));
            await firstProductLink.click();
            await this.driver.sleep(5000); // Page load hone dein

            console.log("Checking Free Shipping...");
            try {
                let pageText = await this.driver.findElement(By.tagName("body")).getText();
                if(pageText.toLowerCase().includes("free shipping")) {
                    console.log("Result: FREE SHIPPING IS AVAILABLE! 🎉");
                } else {
                    console.log("Result: Free Shipping is NOT available for this product.");
                }
            } catch (err) {
                console.log("Could not determine shipping status:", err.message);
            }
        } else {
            console.log("No products available to click.");
        }
    }
}

module.exports = ProductPage;