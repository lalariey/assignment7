const { By, Key, until } = require("selenium-webdriver");

class HomePage {
    constructor(driver) {
        this.driver = driver;
    }

    async searchProduct() {
        console.log("Searching started...");

        // 1. Wait karein jab tak search box screen par nazar na aa jaye (Maximum 10 seconds)
        let searchBox = await this.driver.wait(
            until.elementLocated(By.name("q")), 
            10000
        );
        
        console.log("Search box found!");

        // 2. Clear karein agar pehle se kuch likha ho aur "electronics" type karein
        await searchBox.clear();
        await searchBox.sendKeys("electronics", Key.RETURN); // Text likh kar Enter press karega

        console.log("Search term submitted successfully.");
    }
}

module.exports = HomePage;